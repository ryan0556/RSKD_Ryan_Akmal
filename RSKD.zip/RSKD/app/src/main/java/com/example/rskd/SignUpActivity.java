package com.example.rskd;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {
    private String role;
    private EditText etNama, etNIK, etNIP, etNoTelp, etTempatLahir, etEmail, etPassword;
    private View tilNIK, tilNIP;
    private Button btnDatePicker, btnDaftar, btnKembali;
    private Spinner spSpesialis, spPendidikan;
    private LinearLayout layoutDokterFields;
    private TextView tvError;
    private ProgressBar progressBar;
    private String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        role = getIntent().getStringExtra("role");

        etNama = findViewById(R.id.etNama);
        etNIK = findViewById(R.id.etNIK);
        etNIP = findViewById(R.id.etNIP);
        tilNIK = findViewById(R.id.tilNIK);
        tilNIP = findViewById(R.id.tilNIP);
        etNoTelp = findViewById(R.id.etNoTelp);
        etTempatLahir = findViewById(R.id.etTempatLahir);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnDatePicker = findViewById(R.id.btnDatePicker);
        btnDaftar = findViewById(R.id.btnDaftar);
        btnKembali = findViewById(R.id.btnKembali);
        spSpesialis = findViewById(R.id.spSpesialis);
        spPendidikan = findViewById(R.id.spPendidikan);
        layoutDokterFields = findViewById(R.id.layoutDokterFields);
        tvError = findViewById(R.id.tvError);
        progressBar = findViewById(R.id.progressBar);

        if ("dokter".equals(role)) {
            tilNIP.setVisibility(View.VISIBLE);
            tilNIK.setVisibility(View.GONE);
            layoutDokterFields.setVisibility(View.VISIBLE);
            setupSpinners();
        } else {
            tilNIP.setVisibility(View.GONE);
            tilNIK.setVisibility(View.VISIBLE);
            layoutDokterFields.setVisibility(View.GONE);
        }

        btnDatePicker.setOnClickListener(v -> showDatePicker());
        btnDaftar.setOnClickListener(v -> register());
        btnKembali.setOnClickListener(v -> finish());
    }

    private void setupSpinners() {
        String[] spesialis = {"Bedah", "Penyakit Dalam", "Anak", "Kandungan", "Saraf", "Jantung"};
        ArrayAdapter<String> adapterSp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, spesialis);
        adapterSp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSpesialis.setAdapter(adapterSp);

        String[] pendidikan = {"S1", "Profesi", "S2", "S3"};
        ArrayAdapter<String> adapterPd = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pendidikan);
        adapterPd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPendidikan.setAdapter(adapterPd);
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            selectedDate = String.format(java.util.Locale.US, "%04d-%02d-%02d", year, (month + 1), dayOfMonth);
            btnDatePicker.setText(selectedDate);
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void register() {
        String nama = etNama.getText().toString().trim();
        String nik = etNIK.getText().toString().trim();
        String nip = etNIP.getText().toString().trim();
        String noTelp = etNoTelp.getText().toString().trim();
        String tempatLahir = etTempatLahir.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (nama.isEmpty() || noTelp.isEmpty() || tempatLahir.isEmpty() || selectedDate.isEmpty() || email.isEmpty() || password.isEmpty()) {
            tvError.setText("Harap isi semua field wajib");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        if ("dokter".equals(role)) {
            if (nip.isEmpty()) {
                tvError.setText("NIP wajib diisi untuk Dokter");
                tvError.setVisibility(View.VISIBLE);
                return;
            }
        } else {
            if (nik.isEmpty()) {
                tvError.setText("NIK wajib diisi");
                tvError.setVisibility(View.VISIBLE);
                return;
            }
        }

        tvError.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.REGISTER_URL,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        boolean success = false;
                        if (jsonObject.has("success")) {
                            success = jsonObject.getBoolean("success");
                        } else if (jsonObject.has("status")) {
                            success = jsonObject.getString("status").equals("success");
                        }

                        if (success) {
                            Toast.makeText(SignUpActivity.this, "Pendaftaran Berhasil", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            tvError.setText(jsonObject.getString("message"));
                            tvError.setVisibility(View.VISIBLE);
                        }
                    } catch (JSONException e) {
                        tvError.setText("Error: " + e.getMessage());
                        tvError.setVisibility(View.VISIBLE);
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    tvError.setText("Error koneksi: " + error.getMessage());
                    tvError.setVisibility(View.VISIBLE);
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("role", role);
                params.put("nama", nama);
                params.put("nik", nik);
                if ("dokter".equals(role)) {
                    params.put("nip", nip);
                    params.put("spesialis", spSpesialis.getSelectedItem().toString());
                    params.put("pendidikan", spPendidikan.getSelectedItem().toString());
                }
                params.put("no_telp", noTelp);
                params.put("tempat_lahir", tempatLahir);
                params.put("tanggal_lahir", selectedDate);
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);
    }
}
