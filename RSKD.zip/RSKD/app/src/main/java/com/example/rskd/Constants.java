package com.example.rskd;

public class Constants {
    public static final String BASE_URL = "http://10.0.2.2/rsdharmais/";
    public static final String LOGIN_URL = BASE_URL + "login.php";
    public static final String REGISTER_URL = BASE_URL + "register.php";
    public static final String GET_HOME_DOKTER = BASE_URL + "get_home_dokter.php";
    public static final String UPDATE_STATUS_PERTEMUAN = BASE_URL + "update_status_pertemuan.php";
    public static final String GET_HISTORY_DOKTER = BASE_URL + "get_history_dokter.php";
    public static final String TAMBAH_JADWAL = BASE_URL + "tambah_jadwal.php";
    public static final String TAMBAH_KONTROL = BASE_URL + "tambah_kontrol.php";
    public static final String UPDATE_PROFIL_DOKTER = BASE_URL + "update_profil_dokter.php";
    public static final String HAPUS_AKUN = BASE_URL + "hapus_akun.php";
    public static final String GET_HOME_PASIEN = BASE_URL + "get_home_pasien.php";
    public static final String BATALKAN_PERJANJIAN = BASE_URL + "batalkan_perjanjian.php";
    public static final String GET_DOKTER_BY_SPESIALIS = BASE_URL + "get_dokter_by_spesialis.php";
    public static final String GET_JADWAL_TERSEDIA = BASE_URL + "get_jadwal_tersedia.php";
    public static final String BUAT_PERJANJIAN = BASE_URL + "buat_perjanjian.php";
    public static final String GET_LIST_DOKTER = BASE_URL + "get_list_dokter.php";
    public static final String GET_JADWAL_DOKTER = BASE_URL + "get_jadwal_dokter.php";
    public static final String GET_HISTORY_PASIEN = BASE_URL + "get_history_pasien.php";
    public static final String UPDATE_PROFIL_PASIEN = BASE_URL + "update_profil_pasien.php";
    public static final String EDIT_JADWAL = BASE_URL + "edit_jadwal.php";
    public static final String HAPUS_JADWAL = BASE_URL + "hapus_jadwal.php";
    public static final String GET_JADWAL_DOKTER_ALL = BASE_URL + "get_jadwal_dokter.php";
}
