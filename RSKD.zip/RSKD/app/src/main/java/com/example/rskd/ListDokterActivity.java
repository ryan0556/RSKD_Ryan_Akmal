package com.example.rskd;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListDokterActivity extends AppCompatActivity {
    private RecyclerView rvDokter;
    private EditText etSearch;
    private Spinner spSpesialis;
    private SessionManager sessionManager;
    private List<JSONObject> dokterList;
    private DokterAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_dokter);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        rvDokter = findViewById(R.id.rvDokter);
        etSearch = findViewById(R.id.etSearch);
        spSpesialis = findViewById(R.id.spSpesialis);

        setupFilters();

        rvDokter.setLayoutManager(new LinearLayoutManager(this));
        dokterList = new ArrayList<>();
        adapter = new DokterAdapter();
        rvDokter.setAdapter(adapter);

        setupBottomNavigation();
        loadDokter();
    }

    private void setupFilters() {
        String[] spesialis = {"Semua", "Bedah", "Penyakit Dalam", "Anak", "Kandungan", "Saraf", "Jantung"};
        ArrayAdapter<String> adapterSp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, spesialis);
        adapterSp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSpesialis.setAdapter(adapterSp);

        spSpesialis.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadDokter();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadDokter();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadDokter() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_LIST_DOKTER,
                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");
                        dokterList.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            dokterList.add(jsonArray.getJSONObject(i));
                        }
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Format data salah", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("spesialis", spSpesialis.getSelectedItem().toString());
                params.put("search", etSearch.getText().toString());
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void showJadwalPopup(String dokterId, String namaDokter) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_JADWAL_DOKTER,
                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            sb.append(obj.getString("hari")).append(": ")
                              .append(obj.getString("jam_mulai")).append(" - ")
                              .append(obj.getString("jam_selesai")).append("\n");
                        }
                        new AlertDialog.Builder(this)
                                .setTitle("Jadwal Praktek: " + namaDokter)
                                .setMessage(sb.length() > 0 ? sb.toString() : "Tidak ada jadwal.")
                                .setPositiveButton("Tutup", null)
                                .show();
                    } catch (JSONException e) { e.printStackTrace(); }
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("dokter_id", dokterId);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private class DokterAdapter extends RecyclerView.Adapter<DokterAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(ListDokterActivity.this).inflate(R.layout.item_dokter, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            try {
                JSONObject obj = dokterList.get(position);
                String nama = obj.getString("nama");
                String spesialis = obj.getString("spesialis");
                String pendidikan = obj.optString("pendidikan", "");
                String status = obj.optString("status_tersedia", "Tidak Tersedia");

                holder.tvNama.setText(nama);
                holder.tvSpesialis.setText(spesialis + (pendidikan.isEmpty() ? "" : " | " + pendidikan));
                holder.tvStatus.setText(status);

                if ("Tersedia".equalsIgnoreCase(status)) {
                    holder.tvStatus.setTextColor(Color.parseColor("#4CAF50"));
                    holder.tvStatus.setBackgroundColor(Color.parseColor("#E8F5E9"));
                } else {
                    holder.tvStatus.setTextColor(Color.parseColor("#F44336"));
                    holder.tvStatus.setBackgroundColor(Color.parseColor("#FFEBEE"));
                }

                holder.itemView.setOnClickListener(v -> {
                    try {
                        showJadwalPopup(obj.getString("id"), obj.getString("nama"));
                    } catch (JSONException e) { e.printStackTrace(); }
                });
            } catch (JSONException e) { e.printStackTrace(); }
        }

        @Override
        public int getItemCount() { return dokterList.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvNama, tvSpesialis, tvStatus;
            ViewHolder(View v) {
                super(v);
                tvNama = v.findViewById(R.id.tvNama);
                tvSpesialis = v.findViewById(R.id.tvSpesialis);
                tvStatus = v.findViewById(R.id.tvStatus);
            }
        }
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_list_dokter);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                startActivity(new Intent(this, PasienHomeActivity.class));
                return true;
            }
            if (id == R.id.menu_history) {
                startActivity(new Intent(this, PasienHistoryActivity.class));
                return true;
            }
            if (id == R.id.menu_buat_perjanjian) {
                startActivity(new Intent(this, BuatPerjanjianActivity.class));
                return true;
            }
            if (id == R.id.menu_list_dokter) return true;
            if (id == R.id.menu_profil) {
                startActivity(new Intent(this, PasienProfilActivity.class));
                return true;
            }
            return false;
        });
    }
}
