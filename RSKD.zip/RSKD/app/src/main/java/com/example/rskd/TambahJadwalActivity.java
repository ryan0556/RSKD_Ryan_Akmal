package com.example.rskd;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TambahJadwalActivity extends AppCompatActivity {
    private Spinner spHari;
    private Button btnJamMulai, btnJamSelesai, btnSimpan, btnPickTanggal;
    private RecyclerView rvJadwal;
    private SessionManager sessionManager;
    private String jamMulai = "", jamSelesai = "", selectedJadwalId = "", selectedTanggal = "";
    private List<JSONObject> jadwalList;
    private JadwalAdapter adapter;
    private TextView tvTitle, tvSelectedTanggal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_jadwal);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        tvTitle = findViewById(R.id.tvTitle);
        tvSelectedTanggal = findViewById(R.id.tvSelectedTanggal);
        spHari = findViewById(R.id.spHari);
        btnJamMulai = findViewById(R.id.btnJamMulai);
        btnJamSelesai = findViewById(R.id.btnJamSelesai);
        btnSimpan = findViewById(R.id.btnSimpan);
        btnPickTanggal = findViewById(R.id.btnPickTanggal);
        rvJadwal = findViewById(R.id.rvJadwal);

        String[] hari = {"Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Harian (Gunakan Tanggal)"};
        ArrayAdapter<String> hariAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, hari);
        hariAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spHari.setAdapter(hariAdapter);

        btnPickTanggal.setOnClickListener(v -> showDatePicker());
        btnJamMulai.setOnClickListener(v -> showTimePicker(true));
        btnJamSelesai.setOnClickListener(v -> showTimePicker(false));
        btnSimpan.setOnClickListener(v -> simpanJadwal());

        rvJadwal.setLayoutManager(new LinearLayoutManager(this));
        jadwalList = new ArrayList<>();
        adapter = new JadwalAdapter();
        rvJadwal.setAdapter(adapter);

        setupBottomNavigation();
        loadJadwal();
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            selectedTanggal = String.format(java.util.Locale.US, "%04d-%02d-%02d", year, (month + 1), dayOfMonth);
            tvSelectedTanggal.setText("Jadwal khusus Tanggal: " + selectedTanggal);
            spHari.setSelection(6); // Select "Harian"
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimePicker(boolean isMulai) {
        Calendar c = Calendar.getInstance();
        new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            String time = String.format("%02d:%02d", hourOfDay, minute);
            if (isMulai) {
                jamMulai = time;
                btnJamMulai.setText(jamMulai);
            } else {
                jamSelesai = time;
                btnJamSelesai.setText(jamSelesai);
            }
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
    }

    private void simpanJadwal() {
        if (jamMulai.isEmpty() || jamSelesai.isEmpty()) {
            Toast.makeText(this, "Pilih jam mulai dan selesai", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = selectedJadwalId.isEmpty() ? Constants.TAMBAH_JADWAL : Constants.EDIT_JADWAL;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(this, "Jadwal berhasil disimpan", Toast.LENGTH_SHORT).show();
                    resetForm();
                    loadJadwal();
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                if (!selectedJadwalId.isEmpty()) {
                    params.put("jadwal_id", selectedJadwalId);
                }
                params.put("dokter_id", sessionManager.getUserId());
                params.put("hari", spHari.getSelectedItem().toString());
                params.put("tanggal", selectedTanggal);
                params.put("jam_mulai", jamMulai);
                params.put("jam_selesai", jamSelesai);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void resetForm() {
        selectedJadwalId = "";
        selectedTanggal = "";
        jamMulai = "";
        jamSelesai = "";
        btnJamMulai.setText("Jam Mulai");
        btnJamSelesai.setText("Jam Selesai");
        tvSelectedTanggal.setText("Jadwal akan berulang setiap minggu");
        tvTitle.setText("Atur Jadwal Praktek");
        btnSimpan.setText("Simpan Jadwal Praktek");
    }

    private void loadJadwal() {
        String userId = sessionManager.getUserId();
        if (userId == null) {
            Toast.makeText(this, "Sesi berakhir, silakan login ulang", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_JADWAL_DOKTER_ALL,
                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        if (jsonResponse.optString("status").equals("success")) {
                            JSONArray jsonArray = jsonResponse.getJSONArray("data");
                            jadwalList.clear();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                jadwalList.add(jsonArray.getJSONObject(i));
                            }
                            adapter.notifyDataSetChanged();
                            
                            if (jadwalList.isEmpty()) {
                                // Optional: show "No schedule" text
                            }
                        } else {
                            Toast.makeText(this, "Server error: " + jsonResponse.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Format data tidak sesuai", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(this, "Gagal koneksi ke server", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("dokter_id", userId);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void deleteJadwal(String id) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.HAPUS_JADWAL,
                response -> loadJadwal(),
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("jadwal_id", id);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private class JadwalAdapter extends RecyclerView.Adapter<JadwalAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(TambahJadwalActivity.this).inflate(R.layout.item_jadwal, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            try {
                JSONObject obj = jadwalList.get(position);
                String tgl = obj.optString("tanggal", "");
                if (!tgl.isEmpty() && !tgl.equals("null")) {
                    holder.tvHari.setText(tgl);
                } else {
                    holder.tvHari.setText(obj.getString("hari"));
                }
                holder.tvJam.setText(obj.getString("jam_mulai") + " - " + obj.getString("jam_selesai"));
                
                holder.btnEdit.setOnClickListener(v -> {
                    try {
                        selectedJadwalId = obj.getString("id");
                        jamMulai = obj.getString("jam_mulai");
                        jamSelesai = obj.getString("jam_selesai");
                        btnJamMulai.setText(jamMulai);
                        btnJamSelesai.setText(jamSelesai);
                        
                        String hari = obj.getString("hari");
                        for (int i = 0; i < spHari.getCount(); i++) {
                            if (spHari.getItemAtPosition(i).toString().equals(hari)) {
                                spHari.setSelection(i);
                                break;
                            }
                        }
                        
                        String tanggal = obj.optString("tanggal", "");
                        if (!tanggal.isEmpty() && !tanggal.equals("null")) {
                            selectedTanggal = tanggal;
                            tvSelectedTanggal.setText("Jadwal khusus Tanggal: " + selectedTanggal);
                        } else {
                            selectedTanggal = "";
                            tvSelectedTanggal.setText("Jadwal akan berulang setiap minggu");
                        }
                        
                        tvTitle.setText("Edit Jadwal Praktek");
                        btnSimpan.setText("Update Jadwal");
                    } catch (JSONException e) { e.printStackTrace(); }
                });

                holder.btnHapus.setOnClickListener(v -> {
                    new AlertDialog.Builder(TambahJadwalActivity.this)
                            .setTitle("Hapus Jadwal")
                            .setMessage("Hapus jadwal ini?")
                            .setPositiveButton("Hapus", (d, w) -> {
                                try {
                                    deleteJadwal(obj.getString("id"));
                                } catch (JSONException e) { e.printStackTrace(); }
                            })
                            .setNegativeButton("Batal", null)
                            .show();
                });
            } catch (JSONException e) { e.printStackTrace(); }
        }

        @Override
        public int getItemCount() { return jadwalList.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvHari, tvJam;
            View btnEdit, btnHapus;
            ViewHolder(View v) {
                super(v);
                tvHari = v.findViewById(R.id.tvHari);
                tvJam = v.findViewById(R.id.tvJam);
                btnEdit = v.findViewById(R.id.btnEdit);
                btnHapus = v.findViewById(R.id.btnHapus);
            }
        }
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_tambah_jadwal);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                startActivity(new Intent(this, DokterHomeActivity.class));
                return true;
            }
            if (id == R.id.menu_history) {
                startActivity(new Intent(this, DokterHistoryActivity.class));
                return true;
            }
            if (id == R.id.menu_tambah_jadwal) return true;
            if (id == R.id.menu_list_kontrol) {
                startActivity(new Intent(this, ListKontrolActivity.class));
                return true;
            }
            if (id == R.id.menu_profil) {
                startActivity(new Intent(this, DokterProfilActivity.class));
                return true;
            }
            return false;
        });
    }
}
