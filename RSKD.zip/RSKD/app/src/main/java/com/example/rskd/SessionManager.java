package com.example.rskd;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "RSKD_PREF";
    private static final String KEY_ROLE = "role";
    private static final String KEY_ID = "user_id";
    private static final String KEY_NAMA = "nama";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Context context;

    public SessionManager(Context context) {
        this.context = context;
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void createLoginSession(String role, String id, String nama) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putString(KEY_ROLE, role);
        editor.putString(KEY_ID, id);
        editor.putString(KEY_NAMA, nama);
        editor.commit();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public String getRole() {
        return pref.getString(KEY_ROLE, null);
    }

    public String getUserId() {
        return pref.getString(KEY_ID, null);
    }

    public String getNama() {
        return pref.getString(KEY_NAMA, null);
    }

    public void logout() {
        editor.clear();
        editor.commit();
    }
}
