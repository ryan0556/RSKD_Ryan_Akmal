package com.example.rskd;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PertemuanAdapter extends RecyclerView.Adapter<PertemuanAdapter.ViewHolder> {
    private Context context;
    private List<Pertemuan> list;
    private OnItemClickListener listener;
    private boolean isHistory = false;
    private boolean isPasien = false;

    public interface OnItemClickListener {
        void onItemClick(Pertemuan pertemuan);
    }

    public PertemuanAdapter(Context context, List<Pertemuan> list, OnItemClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    public void setHistory(boolean history) {
        isHistory = history;
    }
    
    public void setPasien(boolean pasien) {
        isPasien = pasien;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pertemuan, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pertemuan item = list.get(position);
        
        if (isPasien) {
            holder.tvNama.setText(item.getNamaDokter());
            holder.tvSubInfo.setText("Spesialis: " + item.getSpesialisDokter());
        } else {
            holder.tvNama.setText(item.getNamaPasien());
            holder.tvSubInfo.setText("Umur: " + item.getUmurPasien());
        }
        
        holder.tvWaktu.setText(item.getTanggal() + " " + item.getWaktu());
        holder.tvTipe.setText(item.getTipe().toUpperCase());

        holder.tvStatus.setVisibility(View.VISIBLE);
        holder.tvStatus.setText(item.getStatus().toUpperCase());
        
        // Color coding for status and indicator
        String status = item.getStatus();
        if ("Selesai".equalsIgnoreCase(status)) {
            holder.tvStatus.setTextColor(Color.parseColor("#4CAF50"));
            holder.indicator.setBackgroundColor(Color.parseColor("#4CAF50"));
            holder.tvStatus.setBackgroundResource(R.drawable.bg_badge_light); // Using a light green bg if possible
        } else if ("Dibatalkan".equalsIgnoreCase(status)) {
            holder.tvStatus.setTextColor(Color.parseColor("#F44336"));
            holder.indicator.setBackgroundColor(Color.parseColor("#F44336"));
        } else if ("Diundur".equalsIgnoreCase(status)) {
            holder.tvStatus.setTextColor(Color.parseColor("#1976D2"));
            holder.indicator.setBackgroundColor(Color.parseColor("#1976D2"));
            holder.tvStatus.setText("DIUNDUR");
        } else {
            // MENUNGGU or others
            holder.tvStatus.setTextColor(Color.parseColor("#FFA000"));
            holder.indicator.setBackgroundColor(Color.parseColor("#FFA000"));
        }

        if ("Perjanjian".equalsIgnoreCase(item.getTipe())) {
            holder.tvTipe.setTextColor(Color.parseColor("#1976D2"));
            holder.tvTipe.setBackgroundResource(R.drawable.bg_badge_light);
        } else {
            // Kontrol
            holder.tvTipe.setTextColor(Color.parseColor("#388E3C"));
            holder.tvTipe.setBackgroundResource(R.drawable.bg_badge_light);
        }

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNama, tvSubInfo, tvWaktu, tvTipe, tvStatus;
        CardView cardPertemuan;
        View indicator;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNama = itemView.findViewById(R.id.tvNama);
            tvSubInfo = itemView.findViewById(R.id.tvSubInfo);
            tvWaktu = itemView.findViewById(R.id.tvWaktu);
            tvTipe = itemView.findViewById(R.id.tvTipe);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            cardPertemuan = itemView.findViewById(R.id.cardPertemuan);
            indicator = itemView.findViewById(R.id.indicator);
        }
    }
}
