package com.example.rskd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PasienHomeActivity extends AppCompatActivity {
    private RecyclerView rvHome;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private View layoutEmpty;
    private SessionManager sessionManager;
    private List<Pertemuan> pertemuanList;
    private PertemuanAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pasien_home);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        rvHome = findViewById(R.id.rvHome);
        progressBar = findViewById(R.id.progressBar);
        layoutEmpty = findViewById(R.id.layoutEmpty);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        swipeRefresh.setOnRefreshListener(this::loadHomeData);
        swipeRefresh.setColorSchemeColors(androidx.core.content.ContextCompat.getColor(this, R.color.primary));

        rvHome.setLayoutManager(new LinearLayoutManager(this));
        pertemuanList = new ArrayList<>();
        adapter = new PertemuanAdapter(this, pertemuanList, pertemuan -> {
            if ("Perjanjian".equalsIgnoreCase(pertemuan.getTipe()) && "menunggu".equalsIgnoreCase(pertemuan.getStatus())) {
                showCancelDialog(pertemuan.getId());
            } else if ("Diundur".equalsIgnoreCase(pertemuan.getStatus())) {
                Toast.makeText(this, "Jadwal ini telah diundur oleh dokter. Silakan cek detail.", Toast.LENGTH_LONG).show();
            }
        });
        adapter.setPasien(true);
        rvHome.setAdapter(adapter);

        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHomeData();
    }

    private void showCancelDialog(String id) {
        new AlertDialog.Builder(this)
                .setTitle("Batalkan Perjanjian")
                .setMessage("Apakah Anda yakin ingin membatalkan perjanjian ini?")
                .setPositiveButton("Ya", (dialog, which) -> batalkanPerjanjian(id))
                .setNegativeButton("Tidak", null)
                .show();
    }

    private void batalkanPerjanjian(String id) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.BATALKAN_PERJANJIAN,
                response -> {
                    Toast.makeText(this, "Perjanjian dibatalkan", Toast.LENGTH_SHORT).show();
                    loadHomeData();
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pertemuan_id", id);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void loadHomeData() {
        if (!swipeRefresh.isRefreshing()) progressBar.setVisibility(View.VISIBLE);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_HOME_PASIEN,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    swipeRefresh.setRefreshing(false);
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");
                        pertemuanList.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            String status = obj.optString("status", "MENUNGGU");
                            
                            // Home shows pending and rescheduled/postponed appointments
                            if ("menunggu".equalsIgnoreCase(status) || "diundur".equalsIgnoreCase(status)) {
                                pertemuanList.add(new Pertemuan(
                                        obj.optString("id", ""),
                                        obj.optString("nama_dokter", obj.optString("nama", "Dokter")),
                                        obj.optString("spesialis", "-"),
                                        obj.optString("tanggal", "-"),
                                        obj.optString("jam_mulai", obj.optString("waktu", "-")),
                                        obj.optString("tipe", "-"),
                                        status,
                                        true
                                ));
                            }
                        }
                        
                        if (pertemuanList.isEmpty()) {
                            layoutEmpty.setVisibility(View.VISIBLE);
                            rvHome.setVisibility(View.GONE);
                        } else {
                            layoutEmpty.setVisibility(View.GONE);
                            rvHome.setVisibility(View.VISIBLE);
                        }

                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "JSON Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    swipeRefresh.setRefreshing(false);
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pasien_id", sessionManager.getUserId());
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_home);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) return true;
            if (id == R.id.menu_history) {
                startActivity(new Intent(this, PasienHistoryActivity.class));
                return true;
            }
            if (id == R.id.menu_buat_perjanjian) {
                startActivity(new Intent(this, BuatPerjanjianActivity.class));
                return true;
            }
            if (id == R.id.menu_list_dokter) {
                startActivity(new Intent(this, ListDokterActivity.class));
                return true;
            }
            if (id == R.id.menu_profil) {
                startActivity(new Intent(this, PasienProfilActivity.class));
                return true;
            }
            return false;
        });
    }
}
