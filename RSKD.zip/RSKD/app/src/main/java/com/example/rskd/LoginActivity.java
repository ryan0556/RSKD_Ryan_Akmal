package com.example.rskd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private String role;
    private EditText etIdentifier, etPassword;
    private TextView tvError, tvLoginTitle;
    private Button btnMasuk, btnDaftar, btnKembali;
    private ProgressBar progressBar;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        role = getIntent().getStringExtra("role");
        sessionManager = new SessionManager(this);

        tvLoginTitle = findViewById(R.id.tvLoginTitle);
        etIdentifier = findViewById(R.id.etIdentifier);
        etPassword = findViewById(R.id.etPassword);
        tvError = findViewById(R.id.tvError);
        btnMasuk = findViewById(R.id.btnMasuk);
        btnDaftar = findViewById(R.id.btnDaftar);
        btnKembali = findViewById(R.id.btnKembali);
        progressBar = findViewById(R.id.progressBar);

        if ("dokter".equals(role)) {
            tvLoginTitle.setText("Login Dokter");
            etIdentifier.setHint("NIP");
        } else {
            tvLoginTitle.setText("Login Pasien");
            etIdentifier.setHint("NIK");
        }

        btnMasuk.setOnClickListener(v -> login());
        btnDaftar.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
            intent.putExtra("role", role);
            startActivity(intent);
        });
        btnKembali.setOnClickListener(v -> finish());
    }

    private void login() {
        String identifier = etIdentifier.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (identifier.isEmpty() || password.isEmpty()) {
            tvError.setText("Harap isi semua field");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        tvError.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.LOGIN_URL,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        boolean success = false;
                        if (jsonObject.has("success")) {
                            success = jsonObject.getBoolean("success");
                        } else if (jsonObject.has("status")) {
                            success = jsonObject.getString("status").equals("success");
                        }

                        if (success) {
                            String id = jsonObject.getString("id");
                            String nama = jsonObject.getString("nama");
                            sessionManager.createLoginSession(role, id, nama);
                            
                            Intent intent;
                            if ("dokter".equals(role)) {
                                intent = new Intent(LoginActivity.this, DokterHomeActivity.class);
                            } else {
                                intent = new Intent(LoginActivity.this, PasienHomeActivity.class);
                            }
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        } else {
                            tvError.setText(jsonObject.getString("message"));
                            tvError.setVisibility(View.VISIBLE);
                        }
                    } catch (JSONException e) {
                        tvError.setText("Error parsing data: " + e.getMessage());
                        tvError.setVisibility(View.VISIBLE);
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    tvError.setText("Error koneksi: " + error.getMessage());
                    tvError.setVisibility(View.VISIBLE);
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("role", role);
                params.put("identifier", identifier);
                params.put("password", password);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);
    }
}
