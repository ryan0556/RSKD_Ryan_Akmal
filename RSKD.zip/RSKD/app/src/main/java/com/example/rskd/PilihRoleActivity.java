package com.example.rskd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class PilihRoleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pilih_role);

        Button btnDokter = findViewById(R.id.btnDokter);
        Button btnPasien = findViewById(R.id.btnPasien);

        btnDokter.setOnClickListener(v -> {
            Intent intent = new Intent(PilihRoleActivity.this, LoginActivity.class);
            intent.putExtra("role", "dokter");
            startActivity(intent);
        });

        btnPasien.setOnClickListener(v -> {
            Intent intent = new Intent(PilihRoleActivity.this, LoginActivity.class);
            intent.putExtra("role", "pasien");
            startActivity(intent);
        });
    }
}
