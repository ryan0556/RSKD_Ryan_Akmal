package com.example.rskd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PasienProfilActivity extends AppCompatActivity {
    private TextView tvNik;
    private EditText etNama, etNoTelp, etEmail;
    private Button btnSimpan, btnHapusAkun, btnKeluar;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pasien_profil);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        tvNik = findViewById(R.id.tvNik);
        etNama = findViewById(R.id.etNama);
        etNoTelp = findViewById(R.id.etNoTelp);
        etEmail = findViewById(R.id.etEmail);
        btnSimpan = findViewById(R.id.btnSimpan);
        btnHapusAkun = findViewById(R.id.btnHapusAkun);
        btnKeluar = findViewById(R.id.btnKeluar);

        loadProfil();

        btnSimpan.setOnClickListener(v -> updateProfil());
        btnKeluar.setOnClickListener(v -> showLogoutDialog());
        btnHapusAkun.setOnClickListener(v -> showHapusAkunDialog());

        setupBottomNavigation();
    }

    private void loadProfil() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.BASE_URL + "get_profil_pasien.php",
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        tvNik.setText(obj.getString("nik"));
                        etNama.setText(obj.getString("nama"));
                        etNoTelp.setText(obj.getString("no_telp"));
                        etEmail.setText(obj.getString("email"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pasien_id", sessionManager.getUserId());
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void updateProfil() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.UPDATE_PROFIL_PASIEN,
                response -> Toast.makeText(this, "Profil diperbarui", Toast.LENGTH_SHORT).show(),
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pasien_id", sessionManager.getUserId());
                params.put("nama", etNama.getText().toString());
                params.put("no_telp", etNoTelp.getText().toString());
                params.put("email", etEmail.getText().toString());
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Keluar")
                .setMessage("Apakah Anda yakin ingin keluar?")
                .setPositiveButton("Ya", (dialog, which) -> {
                    sessionManager.logout();
                    Intent intent = new Intent(this, PilihRoleActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    private void showHapusAkunDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus Akun")
                .setMessage("Tindakan ini tidak bisa dibatalkan. Hapus akun?")
                .setPositiveButton("Hapus", (dialog, which) -> {
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.HAPUS_AKUN,
                            response -> {
                                sessionManager.logout();
                                startActivity(new Intent(this, PilihRoleActivity.class));
                                finish();
                            },
                            error -> {}) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<>();
                            params.put("id", sessionManager.getUserId());
                            params.put("role", "pasien");
                            return params;
                        }
                    };
                    Volley.newRequestQueue(this).add(stringRequest);
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_profil);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                startActivity(new Intent(this, PasienHomeActivity.class));
                return true;
            }
            if (id == R.id.menu_history) {
                startActivity(new Intent(this, PasienHistoryActivity.class));
                return true;
            }
            if (id == R.id.menu_buat_perjanjian) {
                startActivity(new Intent(this, BuatPerjanjianActivity.class));
                return true;
            }
            if (id == R.id.menu_list_dokter) {
                startActivity(new Intent(this, ListDokterActivity.class));
                return true;
            }
            if (id == R.id.menu_profil) return true;
            return false;
        });
    }
}
