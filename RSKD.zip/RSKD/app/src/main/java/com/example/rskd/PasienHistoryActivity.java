package com.example.rskd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PasienHistoryActivity extends AppCompatActivity {
    private RecyclerView rvHistory;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private View layoutEmpty;
    private SessionManager sessionManager;
    private List<Pertemuan> historyList;
    private PertemuanAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pasien_history);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        rvHistory = findViewById(R.id.rvHistory);
        progressBar = findViewById(R.id.progressBar);
        layoutEmpty = findViewById(R.id.layoutEmpty);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        swipeRefresh.setOnRefreshListener(this::loadHistory);
        swipeRefresh.setColorSchemeColors(androidx.core.content.ContextCompat.getColor(this, R.color.primary));

        rvHistory.setLayoutManager(new LinearLayoutManager(this));
        historyList = new ArrayList<>();
        adapter = new PertemuanAdapter(this, historyList, pertemuan -> {
            Intent intent = new Intent(PasienHistoryActivity.this, DetailHistoryPasienActivity.class);
            intent.putExtra("pertemuan_id", pertemuan.getId());
            startActivity(intent);
        });
        adapter.setHistory(true);
        adapter.setPasien(true);
        rvHistory.setAdapter(adapter);

        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }

    private void loadHistory() {
        if (swipeRefresh != null && !swipeRefresh.isRefreshing()) progressBar.setVisibility(View.VISIBLE);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_HISTORY_PASIEN,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray jsonArray = jsonResponse.optJSONArray("data");
                        historyList.clear();
                        
                        if (jsonArray != null) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                String status = obj.optString("status", "MENUNGGU").trim();
                                
                                // History shows anything that is not pending or rescheduled
                                if (!"menunggu".equalsIgnoreCase(status) && !"diundur".equalsIgnoreCase(status)) {
                                    historyList.add(new Pertemuan(
                                            obj.optString("id", ""),
                                            obj.optString("nama_dokter", obj.optString("nama", "Dokter")),
                                            obj.optString("spesialis", "-"),
                                            obj.optString("tanggal", "-"),
                                            obj.optString("jam_mulai", obj.optString("waktu", "-")),
                                            obj.optString("tipe", "-"),
                                            status,
                                            true
                                    ));
                                }
                            }
                        }
                        
                        if (historyList.isEmpty()) {
                            layoutEmpty.setVisibility(View.VISIBLE);
                            rvHistory.setVisibility(View.GONE);
                        } else {
                            layoutEmpty.setVisibility(View.GONE);
                            rvHistory.setVisibility(View.VISIBLE);
                        }

                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
                    Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pasien_id", sessionManager.getUserId());
                // We pull all and filter on client side for consistency with Home
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_history);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                startActivity(new Intent(this, PasienHomeActivity.class));
                return true;
            }
            if (id == R.id.menu_history) return true;
            if (id == R.id.menu_buat_perjanjian) {
                startActivity(new Intent(this, BuatPerjanjianActivity.class));
                return true;
            }
            if (id == R.id.menu_list_dokter) {
                startActivity(new Intent(this, ListDokterActivity.class));
                return true;
            }
            if (id == R.id.menu_profil) {
                startActivity(new Intent(this, PasienProfilActivity.class));
                return true;
            }
            return false;
        });
    }
}
