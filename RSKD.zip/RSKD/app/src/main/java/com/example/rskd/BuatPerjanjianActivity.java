package com.example.rskd;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BuatPerjanjianActivity extends AppCompatActivity {
    private Spinner spSpesialis, spDokter;
    private Button btnCari, btnSimpan;
    private CalendarView calendarView;
    private RecyclerView rvJam;
    private TextView tvLabelJam;
    private SessionManager sessionManager;
    private List<JSONObject> dokterList, jamList;
    private String selectedDate = "";
    private JamAdapter jamAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buat_perjanjian);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        spSpesialis = findViewById(R.id.spSpesialis);
        spDokter = findViewById(R.id.spDokter);
        btnCari = findViewById(R.id.btnCari);
        btnSimpan = findViewById(R.id.btnSimpan);
        calendarView = findViewById(R.id.calendarView);
        rvJam = findViewById(R.id.rvJam);
        tvLabelJam = findViewById(R.id.tvLabelJam);

        setupSpesialisSpinner();

        btnCari.setOnClickListener(v -> showStep2());
        btnSimpan.setOnClickListener(v -> simpanPerjanjian());

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = String.format(java.util.Locale.US, "%04d-%02d-%02d", year, (month + 1), dayOfMonth);
            loadJamTersedia();
        });

        dokterList = new ArrayList<>();
        jamList = new ArrayList<>();
        jamAdapter = new JamAdapter();
        rvJam.setAdapter(jamAdapter);
        rvJam.setNestedScrollingEnabled(false); // Tambahkan ini agar tidak hang

        setupBottomNavigation();
    }

    private void setupSpesialisSpinner() {
        String[] spesialis = {"Bedah", "Penyakit Dalam", "Anak", "Kandungan", "Saraf", "Jantung"};
        ArrayAdapter<String> adapterSp = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, spesialis);
        adapterSp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSpesialis.setAdapter(adapterSp);

        spSpesialis.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadDokterBySpesialis(spesialis[position]);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadDokterBySpesialis(String spec) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_DOKTER_BY_SPESIALIS,
                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");
                        dokterList.clear();
                        List<String> names = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            dokterList.add(obj);
                            names.add(obj.getString("nama"));
                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spDokter.setAdapter(adapter);
                        
                        if (names.isEmpty()) {
                            Toast.makeText(this, "Tidak ada dokter untuk spesialis ini", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) { 
                        e.printStackTrace(); 
                        Toast.makeText(this, "Error parsing data dokter", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("spesialis", spec);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void showStep2() {
        if (spDokter.getSelectedItem() == null) {
            Toast.makeText(this, "Silakan pilih dokter terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Sembunyikan keyboard jika terbuka
        View view = this.getCurrentFocus();
        if (view != null) {
            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager)getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        findViewById(R.id.cvStep2).setVisibility(View.VISIBLE);
        calendarView.setVisibility(View.VISIBLE);
        
        // Set minimum date ke hari ini
        calendarView.setMinDate(System.currentTimeMillis() - 1000);
        
        // Gunakan Handler untuk sedikit menunda proses agar UI tidak hang saat animasi muncul
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
            selectedDate = sdf.format(new java.util.Date(calendarView.getDate()));
            loadJamTersedia();
        }, 300);
    }

    private void loadJamTersedia() {
        if (spDokter.getSelectedItem() == null || selectedDate.isEmpty()) return;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_JADWAL_TERSEDIA,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray jadwalArray = jsonObject.getJSONArray("jadwal");
                        JSONArray bookedArray = jsonObject.getJSONArray("booked");

                        jamList.clear();
                        // Get day of week for selectedDate
                        String[] days = {"Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"};
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault());
                        java.util.Calendar cal = java.util.Calendar.getInstance();
                        cal.setTime(sdf.parse(selectedDate));
                        String dayName = days[cal.get(java.util.Calendar.DAY_OF_WEEK) - 1];

                        for (int i = 0; i < jadwalArray.length(); i++) {
                            JSONObject j = jadwalArray.getJSONObject(i);
                            String schedDate = j.optString("tanggal", "");
                            String schedHari = j.getString("hari");

                            // Prioritize specific date match, or match by day name
                            if ((!schedDate.isEmpty() && !schedDate.equals("null") && schedDate.equals(selectedDate)) || 
                                (schedHari.equalsIgnoreCase(dayName) && (schedDate.isEmpty() || schedDate.equals("null")))) {

                                String start = j.getString("jam_mulai");
                                String end = j.getString("jam_selesai");

                                java.text.SimpleDateFormat timeSdf = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
                                java.util.Date startTime = timeSdf.parse(start);
                                java.util.Date endTime = timeSdf.parse(end);

                                if (startTime == null || endTime == null) continue;

                                java.util.Calendar timeCal = java.util.Calendar.getInstance();
                                timeCal.setTime(startTime);

                                while (timeCal.getTime().before(endTime)) {
                                    String currentJam = timeSdf.format(timeCal.getTime());
                                    timeCal.add(java.util.Calendar.MINUTE, 30);
                                    String endJam = timeSdf.format(timeCal.getTime());
                                    
                                    // Check if booked
                                    boolean isBooked = false;
                                    for (int k = 0; k < bookedArray.length(); k++) {
                                        JSONObject b = bookedArray.getJSONObject(k);
                                        String bookedStart = b.getString("jam_mulai");
                                        // Cek kecocokan jam (mengabaikan detik jika ada)
                                        if (b.getString("tanggal").equals(selectedDate) && bookedStart.startsWith(currentJam)) {
                                            isBooked = true;
                                            break;
                                        }
                                    }

                                    if (!isBooked) {
                                        JSONObject slot = new JSONObject();
                                        slot.put("jam_mulai", currentJam);
                                        slot.put("jam_selesai", endJam);
                                        jamList.add(slot);
                                    }
                                }
                            }
                        }

                        if (jamList.isEmpty()) {
                            Toast.makeText(this, "Tidak ada jadwal tersedia di hari " + dayName, Toast.LENGTH_SHORT).show();
                        }

                        jamAdapter.notifyDataSetChanged();
                        tvLabelJam.setVisibility(View.VISIBLE);
                        rvJam.setVisibility(View.VISIBLE);
                        btnSimpan.setVisibility(View.VISIBLE);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing jadwal: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                try {
                    Map<String, String> params = new HashMap<>();
                    params.put("dokter_id", dokterList.get(spDokter.getSelectedItemPosition()).getString("id"));
                    params.put("tanggal", selectedDate);
                    return params;
                } catch (JSONException e) { return null; }
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void simpanPerjanjian() {
        if (selectedPos == -1) {
            Toast.makeText(this, "Pilih jam terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.BUAT_PERJANJIAN,
                response -> {
                    Toast.makeText(this, "Perjanjian berhasil dibuat", Toast.LENGTH_SHORT).show();
                    finish();
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                try {
                    JSONObject selectedSlot = jamList.get(selectedPos);
                    Map<String, String> params = new HashMap<>();
                    params.put("pasien_id", sessionManager.getUserId());
                    params.put("dokter_id", dokterList.get(spDokter.getSelectedItemPosition()).getString("id"));
                    params.put("tanggal", selectedDate);
                    params.put("jam_mulai", selectedSlot.getString("jam_mulai"));
                    params.put("jam_selesai", selectedSlot.getString("jam_selesai"));
                    return params;
                } catch (JSONException e) { return null; }
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private int selectedPos = -1;
    private class JamAdapter extends RecyclerView.Adapter<JamAdapter.ViewHolder> {
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(BuatPerjanjianActivity.this).inflate(android.R.layout.simple_list_item_1, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            try {
                JSONObject obj = jamList.get(position);
                String label = obj.getString("jam_mulai") + " - " + obj.getString("jam_selesai");
                holder.text1.setText(label);
                holder.text1.setPadding(32, 16, 32, 16);
                holder.text1.setGravity(android.view.Gravity.CENTER);
                
                if (selectedPos == position) {
                    holder.itemView.setBackgroundResource(R.drawable.bg_badge_light);
                    holder.text1.setTextColor(Color.parseColor("#2196F3"));
                    holder.text1.setTypeface(null, android.graphics.Typeface.BOLD);
                } else {
                    holder.itemView.setBackgroundColor(Color.TRANSPARENT);
                    holder.text1.setTextColor(Color.parseColor("#7F8C8D"));
                    holder.text1.setTypeface(null, android.graphics.Typeface.NORMAL);
                }

                holder.itemView.setOnClickListener(v -> {
                    selectedPos = position;
                    notifyDataSetChanged();
                });
            } catch (JSONException e) { e.printStackTrace(); }
        }

        @Override
        public int getItemCount() { return jamList.size(); }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView text1;
            ViewHolder(View v) {
                super(v);
                text1 = v.findViewById(android.R.id.text1);
            }
        }
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_buat_perjanjian);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                startActivity(new Intent(this, PasienHomeActivity.class));
                return true;
            }
            if (id == R.id.menu_history) {
                startActivity(new Intent(this, PasienHistoryActivity.class));
                return true;
            }
            if (id == R.id.menu_buat_perjanjian) return true;
            if (id == R.id.menu_list_dokter) {
                startActivity(new Intent(this, ListDokterActivity.class));
                return true;
            }
            if (id == R.id.menu_profil) {
                startActivity(new Intent(this, PasienProfilActivity.class));
                return true;
            }
            return false;
        });
    }
}
