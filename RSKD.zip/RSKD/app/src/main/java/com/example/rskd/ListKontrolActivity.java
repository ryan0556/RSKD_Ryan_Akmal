package com.example.rskd;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListKontrolActivity extends AppCompatActivity {
    private EditText etNikPasien;
    private Button btnPickDate, btnPickTime, btnSimpan;
    private RecyclerView rvKontrol;
    private SessionManager sessionManager;
    private String selectedDate = "", selectedTime = "";
    private List<Pertemuan> kontrolList;
    private PertemuanAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_kontrol);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        etNikPasien = findViewById(R.id.etNikPasien);
        btnPickDate = findViewById(R.id.btnPickDate);
        btnPickTime = findViewById(R.id.btnPickTime);
        btnSimpan = findViewById(R.id.btnSimpan);
        rvKontrol = findViewById(R.id.rvKontrol);

        btnPickDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                selectedDate = String.format(java.util.Locale.US, "%04d-%02d-%02d", year, (month + 1), dayOfMonth);
                btnPickDate.setText(selectedDate);
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        btnPickTime.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new TimePickerDialog(this, (view, hourOfDay, minute) -> {
                selectedTime = String.format("%02d:%02d", hourOfDay, minute);
                btnPickTime.setText(selectedTime);
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
        });

        btnSimpan.setOnClickListener(v -> simpanKontrol());

        rvKontrol.setLayoutManager(new LinearLayoutManager(this));
        kontrolList = new ArrayList<>();
        adapter = new PertemuanAdapter(this, kontrolList, pertemuan -> {
            Intent intent = new Intent(ListKontrolActivity.this, DetailPertemuanActivity.class);
            intent.putExtra("pertemuan_id", pertemuan.getId());
            intent.putExtra("tipe", "kontrol");
            intent.putExtra("nama_pasien", pertemuan.getNamaPasien());
            intent.putExtra("umur_pasien", pertemuan.getUmurPasien());
            intent.putExtra("waktu", pertemuan.getTanggal() + " " + pertemuan.getWaktu());
            startActivity(intent);
        });
        rvKontrol.setAdapter(adapter);

        setupBottomNavigation();
        loadKontrolList();
    }

    private void simpanKontrol() {
        String nik = etNikPasien.getText().toString().trim();
        if (nik.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
            Toast.makeText(this, "Harap isi semua field", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.TAMBAH_KONTROL,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        if (obj.getString("status").equals("success")) {
                            Toast.makeText(this, "Kontrol berhasil disimpan", Toast.LENGTH_SHORT).show();
                            etNikPasien.setText("");
                            loadKontrolList();
                        } else {
                            Toast.makeText(this, obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("dokter_id", sessionManager.getUserId());
                params.put("nik_pasien", nik);
                params.put("tanggal", selectedDate);
                params.put("waktu", selectedTime);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void loadKontrolList() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.BASE_URL + "get_kontrol_by_dokter.php",
                response -> {
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        kontrolList.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            String status = obj.optString("status", "menunggu");
                            
                            // Only show active/pending controls here
                            if (status.equalsIgnoreCase("menunggu") || status.equalsIgnoreCase("Diundur")) {
                                kontrolList.add(new Pertemuan(
                                        obj.getString("id"),
                                        obj.optString("nama_pasien", obj.optString("nama", "Pasien")),
                                        obj.optString("umur_pasien", "-"),
                                        obj.getString("tanggal"),
                                        obj.optString("jam_mulai", obj.optString("waktu", "-")),
                                        "Kontrol",
                                        status
                                ));
                            }
                        }
                        adapter.notifyDataSetChanged();

                        // Show "notification" if there are new active controls
                        if (!kontrolList.isEmpty()) {
                            com.google.android.material.badge.BadgeDrawable badge = ((BottomNavigationView)findViewById(R.id.bottomNavigation)).getOrCreateBadge(R.id.menu_list_kontrol);
                            badge.setNumber(kontrolList.size());
                            badge.setVisible(true);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("dokter_id", sessionManager.getUserId());
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_list_kontrol);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) {
                startActivity(new Intent(this, DokterHomeActivity.class));
                return true;
            }
            if (id == R.id.menu_history) {
                startActivity(new Intent(this, DokterHistoryActivity.class));
                return true;
            }
            if (id == R.id.menu_tambah_jadwal) {
                startActivity(new Intent(this, TambahJadwalActivity.class));
                return true;
            }
            if (id == R.id.menu_list_kontrol) return true;
            if (id == R.id.menu_profil) {
                startActivity(new Intent(this, DokterProfilActivity.class));
                return true;
            }
            return false;
        });
    }
}
