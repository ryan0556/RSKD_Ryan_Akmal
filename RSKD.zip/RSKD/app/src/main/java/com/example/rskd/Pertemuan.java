package com.example.rskd;

public class Pertemuan {
    private String id;
    private String namaPasien;
    private String umurPasien;
    private String tanggal;
    private String waktu;
    private String tipe;
    private String status;
    private String namaDokter; // For Pasien Home
    private String spesialisDokter; // For Pasien Home

    public Pertemuan(String id, String namaPasien, String umurPasien, String tanggal, String waktu, String tipe, String status) {
        this.id = id;
        this.namaPasien = namaPasien;
        this.umurPasien = umurPasien;
        this.tanggal = tanggal;
        this.waktu = waktu;
        this.tipe = tipe;
        this.status = status;
    }

    // Constructor for Pasien
    public Pertemuan(String id, String namaDokter, String spesialisDokter, String tanggal, String waktu, String tipe, String status, boolean isPasien) {
        this.id = id;
        this.namaDokter = namaDokter;
        this.spesialisDokter = spesialisDokter;
        this.tanggal = tanggal;
        this.waktu = waktu;
        this.tipe = tipe;
        this.status = status;
    }

    public String getId() { return id; }
    public String getNamaPasien() { return namaPasien; }
    public String getUmurPasien() { return umurPasien; }
    public String getTanggal() { return tanggal; }
    public String getWaktu() { return waktu; }
    public String getTipe() { return tipe; }
    public String getStatus() { return status; }
    public String getNamaDokter() { return namaDokter; }
    public String getSpesialisDokter() { return spesialisDokter; }
}
