package com.example.rskd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DokterHomeActivity extends AppCompatActivity {
    private RecyclerView rvHome;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private View layoutEmpty;
    private SessionManager sessionManager;
    private BottomNavigationView bottomNavigationView;
    private List<Pertemuan> pertemuanList;
    private PertemuanAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dokter_home);

        sessionManager = new SessionManager(this);
        TextView tvHeaderNama = findViewById(R.id.tvHeaderNama);
        tvHeaderNama.setText(sessionManager.getNama());

        rvHome = findViewById(R.id.rvHome);
        progressBar = findViewById(R.id.progressBar);
        layoutEmpty = findViewById(R.id.layoutEmpty);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        bottomNavigationView = findViewById(R.id.bottomNavigation);

        swipeRefresh.setOnRefreshListener(this::loadHomeData);
        swipeRefresh.setColorSchemeColors(androidx.core.content.ContextCompat.getColor(this, R.color.primary));

        rvHome.setLayoutManager(new LinearLayoutManager(this));
        pertemuanList = new ArrayList<>();
        adapter = new PertemuanAdapter(this, pertemuanList, pertemuan -> {
            Intent intent = new Intent(DokterHomeActivity.this, DetailPertemuanActivity.class);
            intent.putExtra("pertemuan_id", pertemuan.getId());
            intent.putExtra("tipe", pertemuan.getTipe());
            intent.putExtra("nama_pasien", pertemuan.getNamaPasien());
            intent.putExtra("umur_pasien", pertemuan.getUmurPasien());
            intent.putExtra("waktu", pertemuan.getTanggal() + " " + pertemuan.getWaktu());
            startActivity(intent);
        });
        rvHome.setAdapter(adapter);

        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHomeData();
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setSelectedItemId(R.id.menu_home);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_home) return true;
            if (id == R.id.menu_history) {
                startActivity(new Intent(this, DokterHistoryActivity.class));
                return true;
            }
            if (id == R.id.menu_tambah_jadwal) {
                startActivity(new Intent(this, TambahJadwalActivity.class));
                return true;
            }
            if (id == R.id.menu_list_kontrol) {
                startActivity(new Intent(this, ListKontrolActivity.class));
                return true;
            }
            if (id == R.id.menu_profil) {
                startActivity(new Intent(this, DokterProfilActivity.class));
                return true;
            }
            return false;
        });
    }

    private void loadHomeData() {
        if (swipeRefresh != null && !swipeRefresh.isRefreshing()) progressBar.setVisibility(View.VISIBLE);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.GET_HOME_DOKTER,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray jsonArray = jsonResponse.optJSONArray("data");
                        pertemuanList.clear();
                        
                        if (jsonArray != null) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                String status = obj.optString("status", "MENUNGGU");

                                // Home shows pending and rescheduled/postponed appointments
                                if ("menunggu".equalsIgnoreCase(status) || "diundur".equalsIgnoreCase(status)) {
                                    pertemuanList.add(new Pertemuan(
                                            obj.optString("id", ""),
                                            obj.optString("nama_pasien", obj.optString("nama", "Pasien")),
                                            obj.optString("umur_pasien", "-"),
                                            obj.optString("tanggal", "-"),
                                            obj.optString("jam_mulai", obj.optString("waktu", "-")),
                                            obj.optString("tipe", "-"),
                                            status
                                    ));
                                }
                            }
                        }

                        if (pertemuanList.isEmpty()) {
                            layoutEmpty.setVisibility(View.VISIBLE);
                            rvHome.setVisibility(View.GONE);
                        } else {
                            layoutEmpty.setVisibility(View.GONE);
                            rvHome.setVisibility(View.VISIBLE);
                        }

                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
                    Toast.makeText(this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("dokter_id", sessionManager.getUserId());
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
