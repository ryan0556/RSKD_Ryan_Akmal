package com.example.rskd;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class DetailPertemuanActivity extends AppCompatActivity {
    private String pertemuanId, tipe;
    private TextView tvNama, tvUmur, tvWaktu, tvTipe;
    private Button btnSelesai, btnDibatalkan, btnDiundur;
    private String newDate = "", newTime = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pertemuan);

        pertemuanId = getIntent().getStringExtra("pertemuan_id");
        tipe = getIntent().getStringExtra("tipe");

        tvNama = findViewById(R.id.tvDetailNama);
        tvUmur = findViewById(R.id.tvDetailUmur);
        tvWaktu = findViewById(R.id.tvDetailWaktu);
        tvTipe = findViewById(R.id.tvDetailTipe);
        btnSelesai = findViewById(R.id.btnSelesai);
        btnDibatalkan = findViewById(R.id.btnDibatalkan);
        btnDiundur = findViewById(R.id.btnDiundur);

        loadDetail();

        btnSelesai.setOnClickListener(v -> showActionDialog("Selesai"));
        btnDibatalkan.setOnClickListener(v -> showActionDialog("Dibatalkan"));
        btnDiundur.setOnClickListener(v -> showActionDialog("Diundur"));
    }

    private void loadDetail() {
        tvNama.setText(getIntent().getStringExtra("nama_pasien"));
        tvUmur.setText("Umur: " + getIntent().getStringExtra("umur_pasien"));
        tvWaktu.setText(getIntent().getStringExtra("waktu"));
        tvTipe.setText("Tipe: " + (tipe != null ? tipe : "-"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // If we want to refresh after action, but usually we finish()
    }

    private void showActionDialog(String status) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Konfirmasi " + status);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_action, null);
        builder.setView(view);

        EditText etNotes = view.findViewById(R.id.etNotes);
        Button btnPickDate = view.findViewById(R.id.btnPickDate);
        Button btnPickTime = view.findViewById(R.id.btnPickTime);

        if ("Diundur".equals(status)) {
            btnPickDate.setVisibility(View.VISIBLE);
            btnPickTime.setVisibility(View.VISIBLE);
        }

        btnPickDate.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view1, year, month, dayOfMonth) -> {
                newDate = year + "-" + (month + 1) + "-" + dayOfMonth;
                btnPickDate.setText(newDate);
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        btnPickTime.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new TimePickerDialog(this, (view1, hourOfDay, minute) -> {
                newTime = hourOfDay + ":" + minute;
                btnPickTime.setText(newTime);
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
        });

        builder.setPositiveButton("Simpan", (dialog, which) -> {
            String notes = etNotes.getText().toString().trim();
            if (notes.isEmpty()) {
                Toast.makeText(this, "Catatan wajib diisi", Toast.LENGTH_SHORT).show();
                return;
            }
            updateStatus(status, notes);
        });
        builder.setNegativeButton("Batal", null);
        builder.show();
    }

    private void updateStatus(String status, String notes) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.UPDATE_STATUS_PERTEMUAN,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        if (obj.getBoolean("success")) {
                            Toast.makeText(this, "Berhasil update status", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(this, obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", pertemuanId);
                params.put("tipe", tipe != null ? tipe.toLowerCase() : "");
                params.put("status", status);
                params.put("catatan", notes);
                if ("Diundur".equals(status)) {
                    params.put("tanggal_baru", newDate);
                    params.put("waktu_baru", newTime);
                }
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
