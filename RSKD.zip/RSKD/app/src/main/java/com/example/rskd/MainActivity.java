package com.example.rskd;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sessionManager = new SessionManager(this);

        if (sessionManager.isLoggedIn()) {
            if ("dokter".equals(sessionManager.getRole())) {
                startActivity(new Intent(this, DokterHomeActivity.class));
            } else {
                startActivity(new Intent(this, PasienHomeActivity.class));
            }
        } else {
            startActivity(new Intent(this, PilihRoleActivity.class));
        }
        finish();
    }
}
