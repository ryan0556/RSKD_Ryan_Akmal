package com.example.rskd;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DetailHistoryPasienActivity extends AppCompatActivity {
    private TextView tvWaktuDaftar, tvNamaDokter, tvSpesialis, tvTanggalPertemuan, tvStatus, tvCatatan;
    private String pertemuanId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_history_pasien);

        pertemuanId = getIntent().getStringExtra("pertemuan_id");

        tvWaktuDaftar = findViewById(R.id.tvWaktuDaftar);
        tvNamaDokter = findViewById(R.id.tvNamaDokter);
        tvSpesialis = findViewById(R.id.tvSpesialis);
        tvTanggalPertemuan = findViewById(R.id.tvTanggalPertemuan);
        tvStatus = findViewById(R.id.tvStatus);
        tvCatatan = findViewById(R.id.tvCatatan);

        loadDetail();
    }

    private void loadDetail() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.BASE_URL + "get_detail_history_pasien.php",
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        tvWaktuDaftar.setText("Waktu Daftar: " + obj.getString("waktu_daftar"));
                        tvNamaDokter.setText("Dokter: " + obj.getString("nama_dokter"));
                        tvSpesialis.setText("Spesialis: " + obj.getString("spesialis"));
                        tvTanggalPertemuan.setText("Tanggal: " + obj.getString("tanggal") + " " + obj.getString("waktu"));
                        tvStatus.setText("Status: " + obj.getString("status"));
                        tvCatatan.setText("Catatan dari Dokter: " + obj.getString("catatan"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pertemuan_id", pertemuanId);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
