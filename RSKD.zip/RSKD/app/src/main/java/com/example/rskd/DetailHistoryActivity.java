package com.example.rskd;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DetailHistoryActivity extends AppCompatActivity {
    private TextView tvWaktuDaftar, tvNamaPasien, tvTipePertemuan, tvStatus, tvCatatan;
    private String pertemuanId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_history);

        pertemuanId = getIntent().getStringExtra("pertemuan_id");

        tvWaktuDaftar = findViewById(R.id.tvWaktuDaftar);
        tvNamaPasien = findViewById(R.id.tvNamaPasien);
        tvTipePertemuan = findViewById(R.id.tvTipePertemuan);
        tvStatus = findViewById(R.id.tvStatus);
        tvCatatan = findViewById(R.id.tvCatatan);

        loadDetail();
    }

    private void loadDetail() {
        // Assume an endpoint for detail exists or we pass it.
        // The requirements say "Tampilkan detail history: waktu daftar, nama pasien, tipe pertemuan, status, catatan dari dokter"
        // Let's use a placeholder request if needed, or just set from Intent if passed.
        // For simplicity, let's assume we need to fetch it.
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.BASE_URL + "get_detail_history.php",
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        tvWaktuDaftar.setText("Waktu Daftar: " + obj.optString("waktu_daftar", "-"));
                        tvNamaPasien.setText("Pasien: " + obj.optString("nama_pasien", "-"));
                        tvTipePertemuan.setText("Tipe: " + obj.optString("tipe", "-"));
                        tvStatus.setText("Status: " + obj.optString("status", "-"));
                        tvCatatan.setText("Catatan: " + obj.optString("catatan", "-"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pertemuan_id", pertemuanId);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
