<?php
include 'koneksi.php';
header('Content-Type: application/json');

// Cara yang lebih aman untuk menambah kolom jika belum ada
$checkColumn = mysqli_query($conn, "SHOW COLUMNS FROM jadwal_praktek LIKE 'tanggal'");
if (mysqli_num_rows($checkColumn) == 0) {
    mysqli_query($conn, "ALTER TABLE jadwal_praktek ADD tanggal DATE NULL AFTER hari");
}

$dokter_id   = $_POST['dokter_id'] ?? '';
$hari        = $_POST['hari'] ?? '';
$tanggal     = $_POST['tanggal'] ?? null;
$jam_mulai   = $_POST['jam_mulai'] ?? '';
$jam_selesai = $_POST['jam_selesai'] ?? '';

if ($tanggal == "" || $tanggal == "null" || empty($tanggal)) $tanggal = null;

$stmt = mysqli_prepare($conn,
    "INSERT INTO jadwal_praktek (dokter_id, hari, tanggal, jam_mulai, jam_selesai) VALUES (?, ?, ?, ?, ?)"
);
mysqli_stmt_bind_param($stmt, "issss", $dokter_id, $hari, $tanggal, $jam_mulai, $jam_selesai);

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Jadwal berhasil ditambahkan"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>