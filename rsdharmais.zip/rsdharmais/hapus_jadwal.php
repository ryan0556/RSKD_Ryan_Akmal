<?php
include 'koneksi.php';
header('Content-Type: application/json');

$jadwal_id = $_POST['jadwal_id'] ?? '';

$stmt = mysqli_prepare($conn, "DELETE FROM jadwal_praktek WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $jadwal_id);

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Jadwal berhasil dihapus"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>