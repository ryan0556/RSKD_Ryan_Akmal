<?php
include 'koneksi.php';
header('Content-Type: application/json');

$dokter_id  = $_POST['dokter_id'] ?? '';
$nik_pasien = $_POST['nik_pasien'] ?? '';
$tanggal    = $_POST['tanggal'] ?? '';
$waktu      = $_POST['waktu'] ?? '';

$cek = mysqli_prepare($conn, "SELECT id FROM pasien WHERE nik = ?");
mysqli_stmt_bind_param($cek, "s", $nik_pasien);
mysqli_stmt_execute($cek);
$res = mysqli_stmt_get_result($cek);
$pasien = mysqli_fetch_assoc($res);

if (!$pasien) {
    echo json_encode(["status" => "error", "message" => "NIK pasien tidak ditemukan"]);
    exit;
}

$stmt = mysqli_prepare($conn,
    "INSERT INTO kontrol (pasien_id, dokter_id, tanggal, waktu) VALUES (?, ?, ?, ?)"
);
mysqli_stmt_bind_param($stmt, "iiss", $pasien['id'], $dokter_id, $tanggal, $waktu);
if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Jadwal kontrol berhasil ditambahkan"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>