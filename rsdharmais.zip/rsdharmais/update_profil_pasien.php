<?php
include 'koneksi.php';
header('Content-Type: application/json');

$id      = $_POST['pasien_id'] ?? '';
$nama    = $_POST['nama'] ?? '';
$no_telp = $_POST['no_telp'] ?? '';
$email   = $_POST['email'] ?? '';

$stmt = mysqli_prepare($conn,
    "UPDATE pasien SET nama=?, no_telp=?, email=? WHERE id=?"
);
mysqli_stmt_bind_param($stmt, "sssi", $nama, $no_telp, $email, $id);
if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Profil berhasil diperbarui"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>