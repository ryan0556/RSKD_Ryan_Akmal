<?php
include 'koneksi.php';
header('Content-Type: application/json');

$pasien_id = $_POST['pasien_id'] ?? '';
$today     = date('Y-m-d');
$hasil     = [];

// Ambil Perjanjian
$stmt = mysqli_prepare($conn,
    "SELECT p.id, d.nama AS nama_dokter, d.spesialis, p.tanggal, p.jam_mulai, p.jam_selesai, 'perjanjian' AS tipe, p.status
     FROM perjanjian p JOIN dokter d ON p.dokter_id = d.id
     WHERE p.pasien_id = ? AND p.status IN ('menunggu', 'Diundur', 'Dibatalkan', 'Selesai')
     AND (p.tanggal >= ? OR p.status IN ('menunggu', 'Diundur'))
     ORDER BY p.tanggal ASC"
);
mysqli_stmt_bind_param($stmt, "is", $pasien_id, $today);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($res)) {
    $hasil[] = $row;
}

// Ambil Kontrol (Aliaskan waktu sebagai jam_mulai agar konsisten di Android)
$stmt2 = mysqli_prepare($conn,
    "SELECT k.id, d.nama AS nama_dokter, d.spesialis, k.tanggal, k.waktu AS jam_mulai, '-' AS jam_selesai, 'kontrol' AS tipe, k.status
     FROM kontrol k JOIN dokter d ON k.dokter_id = d.id
     WHERE k.pasien_id = ? AND k.status IN ('menunggu', 'Diundur', 'Dibatalkan', 'Selesai')
     AND (k.tanggal >= ? OR k.status IN ('menunggu', 'Diundur'))
     ORDER BY k.tanggal ASC"
);
mysqli_stmt_bind_param($stmt2, "is", $pasien_id, $today);
mysqli_stmt_execute($stmt2);
$res2 = mysqli_stmt_get_result($stmt2);
while ($row = mysqli_fetch_assoc($res2)) $hasil[] = $row;

// Sort by date and status
usort($hasil, function($a, $b) {
    if ($a['status'] == $b['status']) {
        return strcmp($a['tanggal'] . $a['jam_mulai'], $b['tanggal'] . $b['jam_mulai']);
    }
    $priority = ['Diundur' => 0, 'menunggu' => 1, 'Selesai' => 2, 'Dibatalkan' => 3];
    $prioA = $priority[$a['status']] ?? 9;
    $prioB = $priority[$b['status']] ?? 9;
    return $prioA - $prioB;
});

echo json_encode(["status" => "success", "data" => array_slice($hasil, 0, 20)]);
?>