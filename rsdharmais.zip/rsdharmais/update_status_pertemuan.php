<?php
include 'koneksi.php';
header('Content-Type: application/json');

$tipe         = $_POST['tipe'] ?? '';
$id           = $_POST['id'] ?? '';
$status       = $_POST['status'] ?? '';
$catatan      = $_POST['catatan'] ?? '';
$tanggal_baru = $_POST['tanggal_baru'] ?? null;
$waktu_baru   = $_POST['waktu_baru'] ?? null;

if ($tipe === 'perjanjian') {
    if ($status === 'Diundur' && $tanggal_baru && $waktu_baru) {
        $stmt = mysqli_prepare($conn,
            "UPDATE perjanjian SET status=?, catatan=?, tanggal=?, jam_mulai=? WHERE id=?"
        );
        mysqli_stmt_bind_param($stmt, "ssssi", $status, $catatan, $tanggal_baru, $waktu_baru, $id);
    } else {
        $stmt = mysqli_prepare($conn,
            "UPDATE perjanjian SET status=?, catatan=? WHERE id=?"
        );
        mysqli_stmt_bind_param($stmt, "ssi", $status, $catatan, $id);
    }
} else {
    if ($status === 'Diundur' && $tanggal_baru && $waktu_baru) {
        $stmt = mysqli_prepare($conn,
            "UPDATE kontrol SET status=?, catatan=?, tanggal=?, waktu=? WHERE id=?"
        );
        mysqli_stmt_bind_param($stmt, "ssssi", $status, $catatan, $tanggal_baru, $waktu_baru, $id);
    } else {
        $stmt = mysqli_prepare($conn,
            "UPDATE kontrol SET status=?, catatan=? WHERE id=?"
        );
        mysqli_stmt_bind_param($stmt, "ssi", $status, $catatan, $id);
    }
}

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["success" => true, "message" => "Status berhasil diperbarui"]);
} else {
    echo json_encode(["success" => false, "message" => mysqli_error($conn)]);
}
?>