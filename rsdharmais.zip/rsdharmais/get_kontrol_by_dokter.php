<?php
include 'koneksi.php';
header('Content-Type: application/json');

$dokter_id = $_POST['dokter_id'] ?? '';

$sql = "SELECT k.id, ps.nama AS nama_pasien, ps.tanggal_lahir, k.tanggal, k.waktu, k.status
        FROM kontrol k
        JOIN pasien ps ON k.pasien_id = ps.id
        WHERE k.dokter_id = ?
        ORDER BY k.tanggal DESC, k.waktu DESC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $dokter_id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

$hasil = [];
while ($row = mysqli_fetch_assoc($res)) {
    $lahir = new DateTime($row['tanggal_lahir']);
    $now = new DateTime();
    $row['umur_pasien'] = $lahir->diff($now)->y . " Tahun";
    $hasil[] = $row;
}

echo json_encode($hasil);
?>