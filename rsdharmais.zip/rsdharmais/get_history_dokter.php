<?php
include 'koneksi.php';
header('Content-Type: application/json');

$dokter_id   = $_POST['dokter_id'] ?? '';
$status      = $_POST['status'] ?? '';
$dari        = $_POST['dari'] ?? '';
$sampai      = $_POST['sampai'] ?? '';
$search      = $_POST['search'] ?? '';
$hasil       = [];

$where_status = ($status && $status !== 'Semua') ? "AND p.status = '$status'" : "AND p.status != 'menunggu'";
$where_tgl    = ($dari && $sampai) ? "AND p.tanggal BETWEEN '$dari' AND '$sampai'" : "";
$where_search = $search ? "AND (ps.nama LIKE '%$search%' OR ps.nik LIKE '%$search%')" : "";

$sql = "SELECT p.id, ps.nama AS nama_pasien, ps.tanggal_lahir, p.tanggal, p.jam_mulai AS waktu, p.status, p.catatan, p.created_at, 'perjanjian' AS tipe
        FROM perjanjian p JOIN pasien ps ON p.pasien_id = ps.id
        WHERE p.dokter_id = $dokter_id $where_status $where_tgl $where_search
        UNION ALL
        SELECT k.id, ps.nama AS nama_pasien, ps.tanggal_lahir, k.tanggal, k.waktu, k.status, k.catatan, k.created_at, 'kontrol' AS tipe
        FROM kontrol k JOIN pasien ps ON k.pasien_id = ps.id
        WHERE k.dokter_id = $dokter_id $where_status $where_tgl $where_search
        ORDER BY tanggal DESC";

$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $lahir = new DateTime($row['tanggal_lahir']);
        $now = new DateTime();
        $row['umur_pasien'] = $lahir->diff($now)->y . " Tahun";
        $hasil[] = $row;
    }
    echo json_encode(["status" => "success", "data" => $hasil]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>