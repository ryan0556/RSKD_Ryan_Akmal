<?php
header('Content-Type: application/json');
error_reporting(0);

include "koneksi.php";

$role = $_POST['role'] ?? '';

$nama = trim($_POST['nama'] ?? '');
$nik = trim($_POST['nik'] ?? '');
$no_telp = trim($_POST['no_telp'] ?? '');
$tempat_lahir = trim($_POST['tempat_lahir'] ?? '');
$tanggal_lahir = trim($_POST['tanggal_lahir'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT);

if ($role == "dokter") {

    $nip = trim($_POST['nip'] ?? '');
    $spesialis = trim($_POST['spesialis'] ?? '');
    $pendidikan = trim($_POST['pendidikan'] ?? '');

    $cek = mysqli_query($conn,
        "SELECT * FROM dokter
         WHERE nik='$nik'
         OR nip='$nip'
         OR email='$email'");

    if(mysqli_num_rows($cek)>0){
        echo json_encode([
            "status"=>"error",
            "message"=>"Data dokter sudah terdaftar"
        ]);
        exit;
    }

    $sql = mysqli_query($conn,
        "INSERT INTO dokter
        (nama,nip,nik,no_telp,tempat_lahir,tanggal_lahir,spesialis,pendidikan,email,password)
        VALUES
        ('$nama','$nip','$nik','$no_telp','$tempat_lahir','$tanggal_lahir','$spesialis','$pendidikan','$email','$password')");

}else{

    $cek = mysqli_query($conn,
        "SELECT * FROM pasien
         WHERE nik='$nik'
         OR email='$email'");

    if(mysqli_num_rows($cek)>0){
        echo json_encode([
            "status"=>"error",
            "message"=>"Data pasien sudah terdaftar"
        ]);
        exit;
    }

    $sql = mysqli_query($conn,
        "INSERT INTO pasien
        (nama,nik,no_telp,tempat_lahir,tanggal_lahir,email,password)
        VALUES
        ('$nama','$nik','$no_telp','$tempat_lahir','$tanggal_lahir','$email','$password')");
}

if($sql){

    echo json_encode([
        "status"=>"success",
        "message"=>"Registrasi berhasil"
    ]);

}else{

    echo json_encode([
        "status"=>"error",
        "message"=>mysqli_error($conn)
    ]);

}

mysqli_close($conn);