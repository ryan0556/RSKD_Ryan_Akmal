<?php
include 'koneksi.php';
header('Content-Type: application/json');

$pasien_id = $_POST['pasien_id'] ?? '';
$status    = $_POST['status'] ?? '';
$spesialis = $_POST['spesialis'] ?? '';
$hasil     = [];

$where_s = $status && $status !== 'semua' ? "AND p.status = '$status'" : "AND p.status != 'menunggu'";
$where_sp= $spesialis && $spesialis !== 'semua' ? "AND d.spesialis = '$spesialis'" : "";

$sql = "SELECT p.id, d.nama AS nama_dokter, d.spesialis, p.tanggal, p.jam_mulai, p.status, p.catatan, p.created_at, 'perjanjian' AS tipe
        FROM perjanjian p JOIN dokter d ON p.dokter_id = d.id
        WHERE p.pasien_id = $pasien_id $where_s $where_sp
        UNION ALL
        SELECT k.id, d.nama AS nama_dokter, d.spesialis, k.tanggal, k.waktu, k.status, k.catatan, k.created_at, 'kontrol' AS tipe
        FROM kontrol k JOIN dokter d ON k.dokter_id = d.id
        WHERE k.pasien_id = $pasien_id $where_s $where_sp
        ORDER BY tanggal DESC";

$res = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($res)) $hasil[] = $row;
echo json_encode(["status" => "success", "data" => $hasil]);
?>