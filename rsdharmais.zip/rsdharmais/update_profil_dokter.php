<?php
include 'koneksi.php';
header('Content-Type: application/json');

$id         = $_POST['dokter_id'] ?? '';
$nama       = $_POST['nama'] ?? '';
$no_telp    = $_POST['no_telp'] ?? '';
$email      = $_POST['email'] ?? '';
$spesialis  = $_POST['spesialis'] ?? '';
$pendidikan = $_POST['pendidikan'] ?? '';

$stmt = mysqli_prepare($conn,
    "UPDATE dokter SET nama=?, no_telp=?, email=?, spesialis=?, pendidikan=? WHERE id=?"
);
mysqli_stmt_bind_param($stmt, "sssssi", $nama, $no_telp, $email, $spesialis, $pendidikan, $id);
if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Profil berhasil diperbarui"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>