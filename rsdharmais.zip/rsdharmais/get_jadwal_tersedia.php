<?php
include 'koneksi.php';
header('Content-Type: application/json');

$dokter_id = $_POST['dokter_id'] ?? '';
$today     = date('Y-m-d');

// Ambil semua jadwal praktek dokter (Harian maupun Tanggal Spesifik)
$stmt = mysqli_prepare($conn,
    "SELECT hari, tanggal, jam_mulai, jam_selesai FROM jadwal_praktek WHERE dokter_id = ?"
);
mysqli_stmt_bind_param($stmt, "i", $dokter_id);
mysqli_stmt_execute($stmt);
$res     = mysqli_stmt_get_result($stmt);
$jadwal  = [];
while ($row = mysqli_fetch_assoc($res)) {
    $jadwal[] = $row;
}

// Ambil perjanjian yang sudah ada (booked) agar tidak bisa dipesan lagi
$stmt2 = mysqli_prepare($conn,
    "SELECT tanggal, jam_mulai, jam_selesai FROM perjanjian
     WHERE dokter_id = ? AND status IN ('menunggu', 'Diundur') AND tanggal >= ?
     ORDER BY tanggal ASC"
);
mysqli_stmt_bind_param($stmt2, "is", $dokter_id, $today);
mysqli_stmt_execute($stmt2);
$res2   = mysqli_stmt_get_result($stmt2);
$booked = [];
while ($row = mysqli_fetch_assoc($res2)) {
    $booked[] = $row;
}

echo json_encode([
    "status"  => "success",
    "jadwal"  => $jadwal,
    "booked"  => $booked
]);
?>