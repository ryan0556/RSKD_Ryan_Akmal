<?php
include 'koneksi.php';
header('Content-Type: application/json');

$role       = $_POST['role'] ?? '';
$identifier = $_POST['identifier'] ?? '';
$password   = $_POST['password'] ?? '';

if (empty($role) || empty($identifier) || empty($password)) {
    echo json_encode(["status" => "error", "message" => "Semua field wajib diisi"]);
    exit;
}

if ($role === 'dokter') {
    $stmt = mysqli_prepare($conn, "SELECT id, nama, password FROM dokter WHERE nip = ?");
} else {
    $stmt = mysqli_prepare($conn, "SELECT id, nama, password FROM pasien WHERE nik = ?");
}

mysqli_stmt_bind_param($stmt, "s", $identifier);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user   = mysqli_fetch_assoc($result);

if (!$user) {
    echo json_encode(["status" => "error", "message" => "Akun tidak ditemukan"]);
    exit;
}

if (!password_verify($password, $user['password'])) {
    echo json_encode(["status" => "error", "message" => "Password salah"]);
    exit;
}

echo json_encode([
    "status" => "success",
    "id"     => $user['id'],
    "nama"   => $user['nama'],
    "role"   => $role
]);
?>