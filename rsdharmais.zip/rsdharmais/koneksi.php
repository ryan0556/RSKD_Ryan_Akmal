<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "rsdharmais";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die(json_encode(["status" => "error", "message" => "Koneksi gagal: " . mysqli_connect_error()]));
}
mysqli_set_charset($conn, "utf8");
?>