<?php
include 'koneksi.php';
header('Content-Type: application/json');

$dokter_id = $_POST['dokter_id'] ?? '';
$today     = date('Y-m-d');
$now       = date('H:i:s');
$hasil     = [];

// Perjanjian mendatang
$stmt = mysqli_prepare($conn,
    "SELECT p.id, ps.nama AS nama_pasien, ps.tanggal_lahir, p.tanggal, p.jam_mulai, p.jam_selesai, 'perjanjian' AS tipe, p.status
     FROM perjanjian p
     JOIN pasien ps ON p.pasien_id = ps.id
     WHERE p.dokter_id = ? AND (p.status = 'menunggu' OR p.status = 'Diundur')
       AND (p.tanggal > ? OR (p.tanggal = ? AND p.jam_mulai >= ?))
     ORDER BY p.tanggal ASC, p.jam_mulai ASC"
);
mysqli_stmt_bind_param($stmt, "isss", $dokter_id, $today, $today, $now);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($res)) {
    $lahir           = new DateTime($row['tanggal_lahir']);
    $now_dt          = new DateTime();
    $row['umur_pasien'] = $lahir->diff($now_dt)->y;
    $row['waktu']    = $row['jam_mulai'];
    $hasil[]         = $row;
}

// Kontrol mendatang
$stmt2 = mysqli_prepare($conn,
    "SELECT k.id, ps.nama AS nama_pasien, ps.tanggal_lahir, k.tanggal, k.waktu AS jam_mulai, 'kontrol' AS tipe, k.status
     FROM kontrol k
     JOIN pasien ps ON k.pasien_id = ps.id
     WHERE k.dokter_id = ? AND (k.status = 'menunggu' OR k.status = 'Diundur')
       AND (k.tanggal > ? OR (k.tanggal = ? AND k.waktu >= ?))
     ORDER BY k.tanggal ASC, k.waktu ASC"
);
mysqli_stmt_bind_param($stmt2, "isss", $dokter_id, $today, $today, $now);
mysqli_stmt_execute($stmt2);
$res2 = mysqli_stmt_get_result($stmt2);
while ($row = mysqli_fetch_assoc($res2)) {
    $lahir           = new DateTime($row['tanggal_lahir']);
    $now_dt          = new DateTime();
    $row['umur_pasien'] = $lahir->diff($now_dt)->y;
    $row['waktu']    = $row['jam_mulai'];
    $hasil[]         = $row;
}

usort($hasil, fn($a, $b) => strcmp($a['tanggal'] . $a['jam_mulai'], $b['tanggal'] . $b['jam_mulai']));
echo json_encode(["status" => "success", "data" => $hasil]);
?>