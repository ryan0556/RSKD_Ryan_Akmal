<?php
include 'koneksi.php';
header('Content-Type: application/json');

$spesialis = $_POST['spesialis'] ?? '';

// Ambil dokter yang memiliki jadwal praktek saja
$sql = "SELECT DISTINCT d.id, d.nama
        FROM dokter d
        JOIN jadwal_praktek j ON d.id = j.dokter_id
        WHERE d.spesialis = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $spesialis);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode(["status" => "success", "data" => $data]);
?>