<?php
include 'koneksi.php';
header('Content-Type: application/json');

$id   = $_POST['id'] ?? '';
$role = $_POST['role'] ?? '';

$tabel = $role === 'dokter' ? 'dokter' : 'pasien';
$stmt  = mysqli_prepare($conn, "DELETE FROM $tabel WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Akun berhasil dihapus"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>