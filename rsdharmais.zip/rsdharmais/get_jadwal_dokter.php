<?php
include 'koneksi.php';
header('Content-Type: application/json');

$dokter_id = $_POST['dokter_id'] ?? '';

// Cek apakah kolom tanggal sudah ada (penting untuk migrasi awal)
$checkColumn = mysqli_query($conn, "SHOW COLUMNS FROM jadwal_praktek LIKE 'tanggal'");
if (mysqli_num_rows($checkColumn) == 0) {
    $select = "SELECT id, hari, jam_mulai, jam_selesai, NULL as tanggal FROM jadwal_praktek WHERE dokter_id = ? ORDER BY FIELD(hari,'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu') ASC";
} else {
    $select = "SELECT id, hari, tanggal, jam_mulai, jam_selesai FROM jadwal_praktek WHERE dokter_id = ? ORDER BY tanggal ASC, FIELD(hari,'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu') ASC";
}

$stmt = mysqli_prepare($conn, $select);
mysqli_stmt_bind_param($stmt, "i", $dokter_id);
mysqli_stmt_execute($stmt);
$res   = mysqli_stmt_get_result($stmt);
$data  = [];
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        $data[] = $row;
    }
}

echo json_encode(["status" => "success", "data" => $data]);
?>