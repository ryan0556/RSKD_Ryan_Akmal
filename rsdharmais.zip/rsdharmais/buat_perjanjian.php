<?php
include 'koneksi.php';
header('Content-Type: application/json');

$pasien_id  = $_POST['pasien_id'] ?? '';
$dokter_id  = $_POST['dokter_id'] ?? '';
$tanggal    = $_POST['tanggal'] ?? '';
$jam_mulai  = $_POST['jam_mulai'] ?? '';
$jam_selesai= $_POST['jam_selesai'] ?? '';

// Cek bentrok
$cek = mysqli_prepare($conn,
    "SELECT id FROM perjanjian WHERE dokter_id=? AND tanggal=? AND status='menunggu'
     AND ((jam_mulai < ? AND jam_selesai > ?))"
);
mysqli_stmt_bind_param($cek, "isss", $dokter_id, $tanggal, $jam_selesai, $jam_mulai);
mysqli_stmt_execute($cek);
mysqli_stmt_store_result($cek);
if (mysqli_stmt_num_rows($cek) > 0) {
    echo json_encode(["status" => "error", "message" => "Slot waktu sudah terisi"]);
    exit;
}

$stmt = mysqli_prepare($conn,
    "INSERT INTO perjanjian (pasien_id, dokter_id, tanggal, jam_mulai, jam_selesai) VALUES (?,?,?,?,?)"
);
mysqli_stmt_bind_param($stmt, "iisss", $pasien_id, $dokter_id, $tanggal, $jam_mulai, $jam_selesai);
if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Perjanjian berhasil dibuat"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>