<?php
include 'koneksi.php';
header('Content-Type: application/json');

$id = $_POST['id'] ?? '';
$stmt = mysqli_prepare($conn,
    "UPDATE perjanjian SET status='dibatalkan' WHERE id=?"
);
mysqli_stmt_bind_param($stmt, "i", $id);
if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["status" => "success", "message" => "Perjanjian berhasil dibatalkan"]);
} else {
    echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
}
?>