<?php
include 'koneksi.php';
header('Content-Type: application/json');

$pasien_id = $_POST['pasien_id'] ?? '';

$stmt = mysqli_prepare($conn, "SELECT id, nik, nama, no_telp, email FROM pasien WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $pasien_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if ($user) {
    echo json_encode($user);
} else {
    echo json_encode(["status" => "error", "message" => "Profil tidak ditemukan"]);
}
?>