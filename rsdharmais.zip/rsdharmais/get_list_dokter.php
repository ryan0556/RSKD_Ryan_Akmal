<?php
include 'koneksi.php';
header('Content-Type: application/json');

$search    = $_POST['search'] ?? '';
$spesialis = $_POST['spesialis'] ?? '';

$where = "WHERE 1=1";
if ($search)    $where .= " AND d.nama LIKE '%$search%'";
if ($spesialis && $spesialis !== 'Semua' && $spesialis !== 'Semua Spesialis' && $spesialis !== '') {
    $where .= " AND d.spesialis = '$spesialis'";
}

// Query untuk mengambil data dokter beserta status ketersediaan (punya jadwal atau tidak)
$sql = "SELECT d.id, d.nama, d.spesialis, d.no_telp, d.pendidikan,
        (SELECT COUNT(*) FROM jadwal_praktek WHERE dokter_id = d.id) as total_jadwal
        FROM dokter d
        $where
        ORDER BY d.nama ASC";

$res  = mysqli_query($conn, $sql);
$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    // Tentukan status ketersediaan
    $row['status_tersedia'] = ($row['total_jadwal'] > 0) ? "Tersedia" : "Tidak Tersedia";
    $data[] = $row;
}

echo json_encode(["status" => "success", "data" => $data]);
?>