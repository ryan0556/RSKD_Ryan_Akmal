<?php
include 'koneksi.php';
header('Content-Type: application/json');

$search    = $_POST['search'] ?? '';
$spesialis = $_POST['spesialis'] ?? '';

$where = "WHERE 1=1";
if ($search)    $where .= " AND nama LIKE '%$search%'";
if ($spesialis && $spesialis !== 'semua') $where .= " AND spesialis = '$spesialis'";

$res  = mysqli_query($conn, "SELECT id, nama, spesialis, no_telp FROM dokter $where ORDER BY nama ASC");
$data = [];
while ($row = mysqli_fetch_assoc($res)) $data[] = $row;
echo json_encode(["status" => "success", "data" => $data]);
?>